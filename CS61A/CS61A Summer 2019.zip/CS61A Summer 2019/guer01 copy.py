def paths(m, n):
    """
    >>> paths(2, 2)
    2
    >>> paths(117, 1)
    1
    """
    if m == 1 or n == 1:
        return 1
    else:
        return paths(m-1, n) + paths(m, n-1)

def merge(s1, s2):
    """ Merges two sorted lists
    >>> merge([1, 3], [2, 4])
    [1, 2, 3, 4]
    >>> merge([1, 2], [])
    [1, 2]
    """
    if s1 == [] or s2 == []:
        return s1 + s2
    elif s1[0] < s2[0]:
        return [s1[0]] + merge(s1[1:], s2)
    else:
        return [s2[0]] + merge(s1, s2[1:])


def mario_number(level):
    """Return the number of ways that Mario can perform a sequence of steps
    or jumps to reach the end of the level without ever landing in a Piranha
    plant. Assume that every level begins and ends with a space.
    4 Recursion and Tree Recursion, HOFs
    >>> mario_number(' P P ') # jump, jump
    1
    >>> mario_number(' P P ') # jump, jump, step
    1
    >>> mario_number(' P P ') # step, jump, jump
    1
    >>> mario_number(' P P ') # step, step, jump, jump or jump, jump, jump
    2
    >>> mario_number(' P PP ') # Mario cannot jump two plants
    0
    >>> mario_number(' ') # step, jump ; jump, step ; step, step, step
    3
    >>> mario_number(' P ')
    9
    >>> mario_number(' P P P P P P P P ')
    180
    """
    if len(level) <= 2:
        return 1
    elif level[1] == "P" and level[2] == " ":
        return mario_number(level[1:len(level)])
    elif level[1] == " ":
        return mario_number(level[2:len(level)]) + mario_number(level[1:len(level)])
##    elif level[1] == " ": # step or jump
##        return 2 * mario_number(level[1:len(level)]) + mario_number(level[2:len(level)])
    else:
        return 0


def make_skipper(n):
    """
    takes in a number n and outputs a function. When
    this function takes in a number x, it prints out all the numbers between 0 and x,
    skipping every nth number (meaning skip any value that is a multiple of n).
    >>> a = make_skipper(2)
    >>> a(5)
    1
    3
    5
    """
    def skipper(x):
        while n != 0:
            return 0
        return 0
    return 0


def keep_ints(cond, n):
    """
    2.6 Write a function that takes in a function cond and a number n and prints numbers
    from 1 to n where calling cond on that number returns True.
    Print out all integers 1..i..n where cond(i) is true
    >>> def is_even(x):
    ... # Even numbers have remainder 0 when divided by 2.
    ... return x % 2 == 0
    >>> keep_ints(is_even, 5)
    2
    4
    """
    return 0

def make_keeper(n):
    """
    2.7 Write a function similar to keep_ints like before, but now it takes in a number n
    and returns a function that has one parameter cond. The returned function prints
    out numbers from 1 to n where calling cond on that number returns True.

    Returns a function which takes one parameter cond and prints out
    all integers 1..i..n where calling cond(i) returns True.
    >>> def is_even(x):
    ... # Even numbers have remainder 0 when divided by 2.
    ... return x % 2 == 0
    >>> make_keeper(5)(is_even)
    2
    4
    """
    return 0
