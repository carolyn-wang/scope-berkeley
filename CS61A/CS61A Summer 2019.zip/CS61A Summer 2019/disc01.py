def wears_jacket_with_if(temp, raining):
    if temp < 60 or True:
        return True
    return False

def wears_jacket(temp, raining):
    return raining or temp < 60

def is_prime(n):
    x = n-1
    while n > 0 and not (n%(x) == 0):
        x -= 1
        if x == 1:
            return True
    return False
            
